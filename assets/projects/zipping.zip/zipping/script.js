btn= document.getElementsByClassName("extract-btn")[0];
inp= document.getElementById("fileInput");
outputDiv= document.getElementsByClassName("outputList")[0];

var zip= new JSZip();

function handleFiles(file) {
    zip.loadAsync(file).then(function (zipData) {
        var allFiles= [];
        var i= 0;
        zipData.forEach(function (relativePath, zipEntry) {
            allFiles.push((relativePath).toString().split('/'));
        });

        var tree= makeATree(allFiles);

        console.log(tree);
        var str = JSON.stringify(tree, null, 4);
        $('#jstree_demo_div').jstree({
            'core': {
                'data': $.parseJSON(str)
           }
        });

    });

}


inp.addEventListener("change", function (evt) {
    var files= evt.target.files;
    for (var i= 0; i< files.length; i++) {
        handleFiles(files[i]);
    }
})

btn.addEventListener("click", function() {
    outputDiv.style.visibility = 'visible';
});


function makeATree(paths) {
    var tree = [];
    for (var i = 0; i < paths.length; i++) {
        var path = paths[i];
        var currentLevel = tree;
        for (var j = 0; j < path.length; j++) {
            var part = path[j];

            var existingPath = findWhere(currentLevel, 'text', part);

            if (existingPath) {
                currentLevel = existingPath.children;
            } else {
                var newPart = {
                    text: part,
                    children: [],
                }

                currentLevel.push(newPart);
                currentLevel = newPart.children;
            }
        }
    }
    return tree;

    function findWhere(array, key, value) {
        t = 0;
        while (t < array.length && array[t][key] !== value) { t++; };

        if (t < array.length) {
            return array[t]
        } else {
            return false;
        }
    }
}
