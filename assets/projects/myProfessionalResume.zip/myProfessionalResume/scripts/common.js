function clickMenuItem(url) {
    window.location.href = url;
}

let tabHead= document.getElementsByClassName("tab-head")[0];
let tabHead= document.getElementsByClassName("tab-indicator")[0];
let tabHead= document.getElementsByClassName("tab-body")[0];

let tabsPane = tabHead.getElementsByTagName("div");

for (let i= 0; i< tabsPane.length; i++) {
    tabsPane[i].addEventListener("click", function() {
        tabHead.getElementsByClassName("active")[0].classList.remove("active");
        tabsPane[i].classList.add("active");

        tabHead.getElementsByClassName("active")[0].classList.remove("active");
        tabsPane[i].classList.add("active");

    });
}
