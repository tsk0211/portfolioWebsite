# Import Libraries
from tkinter import *
from tkinter import ttk
from time import sleep
import threading     # For Multi-Functioing
from PIL import Image,ImageTk
from os import system

# Creating Main Window. Adding Icon, Background Color, Fullscreen Attribute
bw = Tk()
bw.geometry("1300x700+50+50")
bw.config(bg="#00adef")

# Getting To Screen FullScreen
bw.attributes("-fullscreen",True)

# Loading Images In For Shuffling/Buffering
imgp = ImageTk.PhotoImage(Image.open("tbp.png"))
imgs = ImageTk.PhotoImage(Image.open("sbp.png"))
imgt = ImageTk.PhotoImage(Image.open("pbp.png"))

# Lists For No. Of Dots At A Time
# Having Cordinates Of Circle's Eight Point
xy_listp = [(683,320),(727.8,339.2),(747,384),(727.8,428.8),(683,448),(638.2,428.8),(619,384),(638.2,339.2)]
xy_lists = [(638.2,339.2),(683,320),(727.8,339.2),(747,384),(727.8,428.8),(683,448),(638.2,428.8),(619,384)]
xy_listt = [(619,384),(638.2,339.2),(683,320),(727.8,339.2),(747,384),(727.8,428.8),(683,448),(638.2,428.8)]
# The Last of The Co-Ordinate Of List Is First Of The Next


# Playing Primary Animation Function
def playanip():
    for i in range(6):
        for xp,yp in xy_listp:
            lab = Label(bw,width=4,height=4,image=imgt)
            lab.place(x=xp,y=yp)
            sleep(0.1)
            bw.update_idletasks()
            lab = Label(bw,width=4,height=4,bg="#00adef")
            lab.place(x=xp,y=yp)
            # Updating The IDLE Tasks
            bw.update_idletasks()
            # Adding/Progressing The ProgressBar
            mpb['value'] += 2.1
            pbvl.config(text = str(int(mpb['value']))+" %")

# Playing Secondary Animation Function
def playanis():
    for ia in range(6):
        for xs,ys in xy_lists:
            lab1 = Label(bw,width=4,height=4,image=imgs)
            lab1.place(x=xs,y=ys)
            sleep(0.1)
            bw.update_idletasks()
            lab1 = Label(bw,width=4,height=4,bg="#00adef")
            lab1.place(x=xs,y=ys)

# Playing 3rd Animation Function
def playanit():
    for iw in range(6):
        for xt,yt in xy_listt:
            lab2 = Label(bw,width=4,height=4,image=imgp)
            lab2.place(x=xt,y=yt)
            sleep(0.1)
            bw.update_idletasks()
            lab2 = Label(bw,width=4,height=4,bg="#00adef")
            lab2.place(x=xt,y=yt)

# Creating ProgressBar
mpb = ttk.Progressbar(bw,length=600)
mpb.place(x=400,y=600)

# Creating % Completing Status
pbvl = Label(bw,text='',bg = '#00adef',font=("Cambria",15))
pbvl.place(x=670,y=383)

# Loading Label
loadl = Label(bw,text="Loading....",font=("Cambria",25,'bold'),bg='#00adef',fg='black').place(x=400,y=550)

# Threading Functions For Running At Same Time
threading.Thread(target=playanip).start() 
threading.Thread(target=playanis).start()            # Functioning Multiple Functions At Same Time
threading.Thread(target=playanit).start()

# Function For Quit On Completing ProgressBar
def dist():
    bw.destroy()
    system("python Encode.py")

# Function For Quiting
def quitf(e):
    bw.quit()

# Open Any File After 8 secs
bw.after(8000,dist)

# Binding The Q,q For Quiting
bw.bind("<KeyPress-Q>",quitf)
bw.bind("<KeyPress-q>",quitf)

# Ending Main Loop
bw.mainloop()