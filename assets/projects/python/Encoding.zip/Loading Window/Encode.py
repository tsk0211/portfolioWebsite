from tkinter import *
from tkinter import messagebox
from PIL import ImageTk,Image
from tkinter import filedialog
from getpass import getuser
from win32api import GetSystemMetrics

w , h = GetSystemMetrics(0) , GetSystemMetrics(1)

# Creating Window Giving Title, Shape And Icon
ed = Tk()
ed.title("                                                                            Encode & Decode ")
ed.geometry("1122x635+50+50")
#ed.iconbitmap("C:\\Users\\kulkarni\\SG logo.ico")
ed.attributes("-fullscreen",True)

# Creating Own Encriptic Language Lists
al1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
al2 = ['q','b','s','k','t','f','j','d','m','n','e','l','r','w','a','c','i','v','p','z','o','h','y','x','u','g']
ap1 = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
ap2 = ['Q','S','O','A','N','U','Y','F','P','Z','J','I','H','K','W','V','T','B','G','D','R','L','E','M','X','C']
nl1 = ["",'0','1','2','3','4','5','6','7','8','9']
nle = ["",'6','2','9','8','0','3','7','1','4','5']
symbol = [" ","~","`","!","@","#","$","%","^","&","*","(",")","_","-","+","+","=","{","}","|","[","]","\n","\t",":",";","'",'"',",",".","<",">","?","/","\\"]
symbole = [" ",'\\','/','?','>','<','.',',','"',"'",';',':','\t','\n',']','[','|','}','{','=','+','+','-','_',')','(','*','&','^','%','$','#','@','!','`','~']

# Open File Function
def opnc():
    filr = filedialog.askopenfilename(initialdir = f"C:\\Users\\{getuser()}\\Desktop",filetypes=[("Python File","*.py"),("All Files","*.*")],defaultextension= ".py")
    if filr:
        ecct.delete(1.0,END)
        file = open(filr,"r")
        f = file.read()
        ecct.insert(1.0,f)
        file.close()

def saveas():
    file = filedialog.asksaveasfilename(defaultextension=".txt",filetypes = [("TXT File","*.txt"),("Python File","*.py"),("All Files","*.*")],initialdir="C:\\Users\\Kulkarni\\Desktop")
    if file:
        file = open(file,'w')
        file.write(encript_data.get(1.0,END))
        file.close()

# Mainloop Function
def edsp():
    global encript_data
    en = n1.get()
    dn = n2.get()
    if en == 1:
        cte = ecct.get('1.0',END)
        text = str(cte)
        nl = len(text)
        i = 0
        lw = ""
        while nl > 0:
            w = text[i]
            if w in al1:
                ind = al1.index(w)
                w = al2[ind]
                lw += w
            elif w in ap1:
                ind = ap1.index(w)
                w = ap2[ind]
                lw += w
            elif w in nl1:
                ind = nl1.index(w)
                w = nle[ind]
                lw += w
            if w in symbol:
                ind = symbol.index(w)
                w = symbole[ind]
                lw += w

            nl -= 1
            i += 1
        encript_data = Text(ed,font=("Cambria",15,'bold'),borderwidth=1,width=68,height=10,fg='White',background='gray',selectbackground='Gray',selectforeground='gold')
        encript_data.place(x=300,y=450)
        encript_data.delete('1.0',END)
        encript_data.insert('1.0',lw)
    if dn == 1:
        cte = ecct.get('1.0',END)
        text = str(cte)
        nl = len(text)
        i = 0
        lw = ""
        while nl > 0:
            w = text[i]
            if w in ap2:
                ind = ap2.index(w)
                w = ap1[ind]
                lw += w
            elif w in al2:
                ind = al2.index(w)
                w = al1[ind]
                lw += w
            if w in nle:
                ind = nle.index(w)
                w = nl1[ind]
                lw += w
            if w in symbole:
                ind = symbole.index(w)
                w = symbol[ind]
                lw += w
            nl -= 1
            i += 1
        encript_data = Text(ed,font=("Cambria",15,'bold'),borderwidth=1,width=68,height=10,fg='White',background='gray',selectbackground='Gray',selectforeground='gold')
        encript_data.place(x=300,y=450)
        encript_data.delete('1.0',END)
        encript_data.insert('1.0',lw)

qr = Image.open("Backgi1.png").resize((w,h))
i = ImageTk.PhotoImage(qr)
il = Label(ed,image=i)
il.place(x=0,y=0,relheight=1,relwidth=1)

eccl = Label(ed,text="Text ",justify='center',bg='gray',fg='white',font = ("Cambria",15,'bold'))
eccl.place(x=660,y=13)

ecct = Text(ed,font=("Cambria",15,'bold'),width=68,height=10,fg='black',selectbackground='Gray',selectforeground='gold')
ecct.place(x=285 ,y=50)

n1 = IntVar()
cb1 = Checkbutton(ed,onvalue=1,offvalue=0,font=("Cambria",10,'bold'),bg="#fff",variable=n1,text='Encode')
cb1.place(x=450,y=300)

n2 = IntVar()
cb2 = Checkbutton(ed,onvalue=1,offvalue=0,variable=n2,text='Decode',font=("Cambria",10,'bold'),bg="#fff")
cb2.place(x=550,y=300)

butn = Button(ed,text="Encript / Decript",justify='center',bg = 'silver',fg='Navy Blue',font=("Cambria",15,'bold'),command=edsp)
butn.place(x=450,y=370)

opnbtn = Button(ed,text="Open Text File",justify='center',bg = 'silver',fg='Navy Blue',font=("Cambria",12,'bold'),command=opnc)
opnbtn.place(x=800,y=300)

saveasbtn = Button(ed,text="Save File As     ",justify='center',bg = 'silver',fg='Navy Blue',font=("Cambria",12,'bold'),command=saveas)
saveasbtn.place(x=800,y=370)

exit_l = Label(ed,text= "For Exit Press:\n\t Q\nFor Fullscreen:\n\tF\n\tCtrl+F",font=("Cambria",10,'bold')).place(x=15,y=13)

def exitf(e):
    ed.quit()

def scf(e):
    ed.attributes("-fullscreen",False)
    pass

def scnf(e):
    ed.attributes("-fullscreen",True)
    pass


ed.bind("<KeyPress-q>",exitf)
ed.bind("<KeyPress-Q>",exitf)
ed.bind("<KeyPress-f>",scf)
ed.bind("<KeyPress-F>",scf)
ed.bind("<Control-KeyPress-f>",scnf)
ed.bind("<Control-KeyPress-f>",scnf)

ed.mainloop()