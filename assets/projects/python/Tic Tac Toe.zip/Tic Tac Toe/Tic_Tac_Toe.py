from tkinter import Tk, Button, Menu, Label
from tkinter.messagebox import askyesno

class Btn :
    def __init__(self, window, name, bg= "#272822", fg= "#F8F8F6") :
        self.root = window
        self.name = name
        self.FG, self.BG = fg, bg

        self.button = Button(self.root, name= self.name, text= "     ", width= 15, height= 6
                            , relief= "raised", bg= self.BG, fg= self.FG, font= ("Halvetica", 12, 'bold'))

class Game :
    def __init__(self, window, bg= "#272822", fg= "#F8F8F6") :
        self.ROOT = window
        self.BG , self.FG = bg, fg
        self.sign = "  O  "

        self.ROOT.title("Tic-Tack-Toe Game  -By Tushar")
        self.MENU = Menu(self.ROOT, bg= self.BG, fg= self.FG)
        self.ROOT.configure(menu= self.MENU)

        self.MENU.add_command(label= "Restart", command= self.restart, activebackground= "#272822", activeforeground= "#F8F8F6")

        # Creating 1-9 Buttons
        b1 = Btn(self.ROOT, '1')
        b2 = Btn(self.ROOT, '2')
        b3 = Btn(self.ROOT, '3')
        b4 = Btn(self.ROOT, '4')
        b5 = Btn(self.ROOT, '5')
        b6 = Btn(self.ROOT, '6')
        b7 = Btn(self.ROOT, '7')
        b8 = Btn(self.ROOT, '8')
        b9 = Btn(self.ROOT, '9')

        # Creating List For Later Use
        self.LIST = [b1, b2, b3, b4, b5, b6, b7, b8, b9]

        for btn in self.LIST :
            btn.button.bind("<Button-1>", self.click)

        # Packing Buttons
        b1.button.grid(row= 0, column= 0, padx= 5, pady= 2)
        b2.button.grid(row= 0, column= 1, padx= 5, pady= 2)
        b3.button.grid(row= 0, column= 2, padx= 5, pady= 2)
        b4.button.grid(row= 1, column= 0, padx= 5, pady= 2)
        b5.button.grid(row= 1, column= 1, padx= 5, pady= 2)
        b6.button.grid(row= 1, column= 2, padx= 5, pady= 2)
        b7.button.grid(row= 2, column= 0, padx= 5, pady= 2)
        b8.button.grid(row= 2, column= 1, padx= 5, pady= 2)
        b9.button.grid(row= 2, column= 2, padx= 5, pady= 2)

        self.Turn_Label = Label(self.ROOT, text= "Start With O Player", fg= self.BG, font= ("Halvetica", 15, 'bold', 'italic'))
        self.Turn_Label.grid(row= 3, columnspan= 3)

    def restart(self) :
        sure = askyesno(title= "Tic-Tack-Toe Game", message= "Are You Sure To Restart.")
        if sure :
            for d in self.LIST :
                d.button.config(text= "     ", state= 'normal', bg= "#272822")
                d.button.bind("<Button-1>", self.click)
            self.Turn_Label.config(text= "Start With O Player")
            self.sign = "  O  "

    def click(self, event) :
        event.widget.configure(text= self.sign)

        if self.sign == "  O  " :
            self.sign = "  X  "
        elif self.sign == "  X  " :
            self.sign = "  O  "
        self.Turn_Label.config(text= f" {self.sign} Player's Turn")
        
        event.widget.unbind("<Button-1>")
        self.check_game()

    def win(self, winner) :
        for s in self.LIST :
            s.button.unbind("<Button-1>")
            s.button.config(state= 'disabled')
        
        self.Turn_Label.config(text= f"{winner} Player Is Winner . ")
        self.restart()

    def return_txt(self, index) :
        return self.LIST[index].button['text']

    def highlight_win(self, arr) :
    	for i in arr :
    		self.LIST[i].button.configure(bg= "#ff0")

    def check_game(self) :
        for x in ["  X  ", "  O  "] :
            # Horizontal Check
            if ((x == self.return_txt(0)) and (x == self.return_txt(1)) and (x == self.return_txt(2))) :
                self.highlight_win([0,1,2])
                self.win(x)
                return 0
            elif ((x == self.return_txt(3)) and (x == self.return_txt(4)) and (x == self.return_txt(5))) :
                self.highlight_win([3,4,5])
                self.win(x)
                return 0
            elif ((x == self.return_txt(6)) and (x == self.return_txt(7)) and (x == self.return_txt(8))) :
                self.highlight_win([6,7,8])
                self.win(x)
                return 0

            # Vertical Check
            elif ((x == self.return_txt(0)) and (x == self.return_txt(3)) and (x == self.return_txt(6))) :
                self.highlight_win([0,3,6])
                self.win(x)
                return 0
            elif ((x == self.return_txt(1)) and (x == self.return_txt(4)) and (x == self.return_txt(7))) :
                self.highlight_win([1,4,7])
                self.win(x)
                return 0
            elif ((x == self.return_txt(2)) and (x == self.return_txt(5)) and (x == self.return_txt(8))) :
                self.highlight_win([2,5,8])
                self.win(x)
                return 0
            
            # Diagonal Check
            elif ((x == self.return_txt(0)) and (x == self.return_txt(4)) and (x == self.return_txt(8))) :
                self.highlight_win([0,4,8])
                self.win(x)
                return 0
            elif ((x == self.return_txt(2)) and (x == self.return_txt(4)) and (x == self.return_txt(6))) :
                self.highlight_win([2,4,6])
                self.win(x)
                return 0
        
        nums = []
        for f in range(len(self.LIST)) :
            nums.append(str(self.return_txt(f)))
        
        if "     " not in nums :
            self.win(" ")
            self.Turn_Label.config(text= "It's A Tie .")

if __name__ == "__main__" :
    win = Tk()
    win.geometry("510x440")
    win.resizable(False, False)
    win.iconbitmap("1.ico")

    Game(win)
    win.mainloop()