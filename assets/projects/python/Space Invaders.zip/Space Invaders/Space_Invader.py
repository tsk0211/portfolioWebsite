import pygame
import os
import time
import random
pygame.font.init()

wth , hgt = 650 , 650
win = pygame.display.set_mode((wth,hgt))
pygame.display.set_caption("Space Invador Game")

# Images For Ships & Objects
red_sp = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_ship_red_small.png")),(50,50))
grn_sp = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_ship_green_small.png")),(50,50))
blu_sp = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_ship_blue_small.png")),(50,50))
yel_sp = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_ship_yellow.png")),(60,60))
yel_lr = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_laser_yellow.png")),(35,35))
blu_lr = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_laser_blue.png")),(30,30))
grn_lr = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_laser_green.png")),(30,30))
red_lr = pygame.transform.scale(pygame.image.load(os.path.join("assets","pixel_laser_red.png")), (30,30))
bg_img = pygame.transform.scale(pygame.image.load(os.path.join("assets","background-black.png")), (wth,hgt))


class Laser :
	def __init__(self, x, y, image) :
		self.x = x 
		self.y = y
		self.img = image
		self.mask = pygame.mask.from_surface(self.img)

	def draw(self, window) :
		window.blit(self.img, (self.x, self.y))

	def move(self, vel) :
		self.y += vel

	def off_screen(self, height) :
		return not (self.y <= height and self.y >= 0)

	def collusion(self, obj) :
		return collide(obj, self)


def collide(obj1 , obj2) :
	offset_x = obj2.x - obj1.x
	offset_y = obj2.y - obj1.y

	return obj1.mask.overlap(obj2.mask, (offset_x, offset_y)) != None


class Ship :
	COOLDOWN = 30
	def __init__(self, x, y, health= 100) :
		self.x = x
		self.y = y
		self.health = health
		self.ship_img = None
		self.laser_img = None
		self.lasers = []
		self.cool_down = 0

	def draw(self, window) :
		window.blit(self.ship_img, (self.x, self.y))
		for las in self.lasers :
			las.draw(window)

	def move_laser(self, vel, obj) :
		self.cooldown()
		for lase in self.lasers :
			lase.move(vel)
			if lase.off_screen(hgt) :
				self.lasers.remove(lase)
			elif lase.collusion(obj) :
				obj.health -= 10
				self.lasers.remove(lase)
		pass

	def cooldown(self) :
		if self.cool_down >= self.COOLDOWN :
			self.cool_down = 0
		elif self.cool_down > 0 :
			self.cool_down += 1

	def shoot(self) :
		if self.cool_down == 0 :
			laser = Laser(self.x+8, self.y, self.laser_img)
			self.lasers.append(laser)
			self.cool_down = 1

	def get_width(self):
		return self.ship_img.get_width()
	def get_height(self):
		return self.ship_img.get_height()

class Player(Ship) :
	def __init__(self, x, y, health= 100) :
		super().__init__(x, y, health)
		self.ship_img = yel_sp
		self.laser_img = yel_lr
		self.mask = pygame.mask.from_surface(self.ship_img)
		self.health = health
		self.max_h = 100

	def move_laser(self, vel, objs) :
		self.cooldown()
		for lase in self.lasers :
			lase.move(vel)
			if lase.off_screen(hgt) :
				self.lasers.remove(lase)
			else :
				for obj in objs :
					if lase.collusion(obj) :
						objs.remove(obj)
						self.lasers.remove(lase)
	
	def draw(self, window) :
		super().draw(window)
		self.healthbar(window)
		pass

	def healthbar(self, window) :
		pygame.draw.rect(window, (255,0,0), (self.x, self.y + self.ship_img.get_height() + 10,self.ship_img.get_width(), 10))
		pygame.draw.rect(window, (0,255,0), (self.x, self.y + self.ship_img.get_height() + 10, (self.ship_img.get_width() * (self.health/self.max_h)) , 10))
		pass

class Enemy(Ship) :
	COLOR_MAP = { "red" : (red_sp , red_lr) ,
				  "green" : (grn_sp , grn_lr ) ,
				  "blue" : (blu_sp , blu_lr) 
				}
	def __init__(self, x, y, color, health= 100) :
		super().__init__(x, y, health)
		self.ship_img , self.laser_img = self.COLOR_MAP[color]
		self.mask = pygame.mask.from_surface(self.ship_img)

	def move(self, vel) :
		self.y += vel


def main() :
	run = True
	FPS = 60
	level = 0
	lives = 5
	main_font = pygame.font.SysFont('comicsans', 40)
	lost_font = pygame.font.SysFont('comicsans', 60)

	enimies = []
	wave_len = 3


	player_vel = 5
	enimi_vel = 1
	lost = False
	lost_count = 0
	laser_vel = 4

	player = Player(300,570)

	clock = pygame.time.Clock()

	def redraw_win() :
		win.blit(bg_img,(0,0))

		# draw text
		lives_label = main_font.render(f"Lives : {lives}",1,(255,255,255))
		level_label = main_font.render(f"Level : {level}",1,(255,255,255))

		win.blit(lives_label, (10,10))
		win.blit(level_label, (wth - level_label.get_width() - 10 ,10))

		for enemy in enimies :
			enemy.draw(win)

		player.draw(win)

		if lost == True :
			lost_lab = lost_font.render("You Lost !!", 1, (255,255,255))
			win.blit(lost_lab, ((wth/2 - lost_lab.get_width()/2), 350))


		pygame.display.update()
		pass

	while run :
		clock.tick(FPS)
		redraw_win()

		if lives <= 0 :
			lost = True
			lost_count += 1

		if lost :
			if lost_count > FPS * 3 :
				run = False
			else :
				continue

			
		if len(enimies) == 0 :
			level += 1
			wave_len += 5
			for i in range(wave_len) :
				enemy_ship = Enemy(random.randint(50,wth-50), random.randint(-1*int(1000*(level/(level+1))),-100), random.choice(["red","green","blue"]))
				enimies.append(enemy_ship)

		for event in pygame.event.get() :
			if event.type == pygame.QUIT :
				run = False

		keys = pygame.key.get_pressed()
		if keys[pygame.K_a] and player.x - player_vel> 0 :
			player.x -= player_vel
		if keys[pygame.K_d] and player_vel + player.x + player.get_width() < wth:
			player.x += player_vel
		if keys[pygame.K_s] and player.y + player.get_height() + 15 +player_vel < hgt:
			player.y += player_vel
		if keys[pygame.K_w] and player.y - player_vel > 0:
			player.y -= player_vel
		if keys[pygame.K_SPACE] :
			player.shoot()

		for enemy in enimies[:] :
			enemy.move(enimi_vel)
			enemy.move_laser(laser_vel, player)

			if random.randrange(0, 60*4) == 1 :
				enemy.shoot()

			if collide(enemy, player) :
				player.health -= 10
				enimies.remove(enemy)
			elif enemy.y + enemy.get_height() > hgt :
				lives -= 1
				enimies.remove(enemy)
		if player.health <= 0 :
			lives -= 1
			player.health = 100
		player.move_laser(-laser_vel, enimies)


if __name__ == '__main__':
	main()